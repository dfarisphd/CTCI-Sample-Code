/* Copyright (c) 2013 the authors listed at the following URL, and/or
the authors of referenced articles or incorporated external code:
http://en.literateprograms.org/Singly_linked_list_(C_Plus_Plus)?action=history&offset=20060517203723

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Retrieved from: http://en.literateprograms.org/Singly_linked_list_(C_Plus_Plus)?oldid=4813
*/

#include <iostream>

#include "sllist.h"

template <typename T>
void print_list(list<T> const& lst)
{
  typename list<T>::const_iterator it;
  for (it = lst.begin(); it != lst.end(); ++it)
    std::cout << *it << " ";
  std::cout << std::endl;
}

int main()
{
  list<int> lst;
  lst.push_back(2);
  lst.push_back(3);
  lst.push_front(1);
  lst.push_back(4);
  list<int> list2;
  list2 = lst;
  print_list(lst);
  list<int>::iterator it;
  it = lst.begin();
  it++;
  lst.insert_after(it, 42);
  ++it;
  print_list(lst);
  lst.erase_after(++it);
  print_list(lst);
  it = lst.begin();
  *it = 10;
  print_list(lst);
  lst.clear();
  print_list(lst);
  print_list(list2);
  std::fill(list2.begin(), list2.end(), 42);
  print_list(list2);
  return 0;
}
