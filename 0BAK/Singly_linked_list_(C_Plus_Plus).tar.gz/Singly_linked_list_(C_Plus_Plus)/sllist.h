/* Copyright (c) 2013 the authors listed at the following URL, and/or
the authors of referenced articles or incorporated external code:
http://en.literateprograms.org/Singly_linked_list_(C_Plus_Plus)?action=history&offset=20060517203723

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Retrieved from: http://en.literateprograms.org/Singly_linked_list_(C_Plus_Plus)?oldid=4813
*/

#include <iterator>

template <typename T>
class list
{
  private:
    struct node
    {
      node(T val)
        : next(NULL), value(val)
      {}

      node* next;
      T     value;
    };

    node* _head;
    node* _tail;
    int _size;

  public:
    class const_iterator
      : public std::iterator<std::forward_iterator_tag, T, size_t, T const*, T const&>
    {
      public:
        typedef std::forward_iterator_tag iterator_category;
	typedef T         value_type;
	typedef ptrdiff_t difference_type;
	typedef T const*  pointer;
	typedef T const&  reference;
	const_iterator(node* cur_node = NULL)
	  : _curpos(cur_node)
	{}
	reference operator*()
	{
	  return _curpos->value;
	}

	pointer operator ->()
	{
	  return &(**this);
	}

	// The lack of arguments indicates that this is prefix ++
	const_iterator& operator++()
	{
	  _curpos = _curpos->next;
	  return *this;
	}

	// The dummy argument indicates that this is the postfix ++
	const_iterator operator++(int)
	{
	  const_iterator old_it = *this;
	  ++(*this);
	  return old_it;
	}

	bool operator ==(const_iterator const& rhs)
	{
	  return _curpos == rhs._curpos;
	}

	bool operator !=(const_iterator const& rhs)
	{
	  return !(*this == rhs);
	}
      protected:
        node* _curpos;
    };

    class iterator
      : public const_iterator
    {
      public:
        iterator(node* iter_node = NULL)
	  : const_iterator(iter_node)
	{}

	typedef std::forward_iterator_tag iterator_category;
	typedef T      value_type;
	typedef size_t difference_type;
	typedef T*     pointer;
	typedef T&     reference;

	using const_iterator::_curpos;

	reference operator*()
	{
	  return _curpos->value;
	}

	pointer operator ->()
	{
	  return &(**this);
	}

	iterator& operator++()
	{
	  _curpos = _curpos->next;
	  return *this;
	}

	iterator operator++(int)
	{
	  iterator old_it = *this;
	  ++(*this);
	  return old_it;
	}
    };

    list();
    list(list<T> const& rhs);
    ~list();
    iterator begin();
    iterator end();
    const_iterator begin() const;
    const_iterator end() const;
    void push_front(T const& elt);
    void push_back(T const& elt);
    void insert_after(iterator where, T const& elt);
    iterator erase_after(iterator it);
    void clear();
    void pop_front();
    list& operator =(list<T> const& rhs);

    size_t size() const;
    bool empty() const;
    friend class list<T>::iterator;
};

#include "sllist.hpp"

