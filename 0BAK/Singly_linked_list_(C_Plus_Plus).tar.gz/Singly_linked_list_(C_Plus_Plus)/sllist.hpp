/* Copyright (c) 2013 the authors listed at the following URL, and/or
the authors of referenced articles or incorporated external code:
http://en.literateprograms.org/Singly_linked_list_(C_Plus_Plus)?action=history&offset=20060517203723

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Retrieved from: http://en.literateprograms.org/Singly_linked_list_(C_Plus_Plus)?oldid=4813
*/

template <typename T>
inline typename list<T>::iterator list<T>::begin()
{
    return iterator(_head);
}

template <typename T>
inline typename list<T>::iterator list<T>::end()
{
    return iterator(NULL);
}
template <typename T>
inline typename list<T>::const_iterator list<T>::begin() const
{
    return const_iterator(_head);
}

template <typename T>
inline typename list<T>::const_iterator list<T>::end() const
{
    return const_iterator(NULL);
}
template <typename T>
inline void list<T>::insert_after(typename list<T>::iterator where, T const& elt)
{
    node* newnode = new node(elt);
    newnode->next = where._curpos->next;
    where._curpos->next = newnode;
    _size++;
    if (newnode->next == NULL)
    {
        _tail = newnode;
    }
}
template <typename T>
inline void list<T>::push_front(T const& elt)
{
    node* newnode = new node(elt);
    newnode->next = _head;
    _head = newnode;
    if (_tail == NULL)
    {
        _tail = newnode;
    }
    _size++;
}
template <typename T>
inline void list<T>::push_back(T const& elt)
{
    if (_tail != NULL)
        insert_after(iterator(_tail), elt);
    else
        push_front(elt);
}
template <typename T>
inline typename list<T>::iterator list<T>::erase_after(typename list<T>::iterator it)
{
    node* todelete = it._curpos->next;
    it._curpos->next = it._curpos->next->next;
    _size--;

    if (it._curpos->next == NULL)
    {
        _tail = it._curpos;
    }
    delete todelete;
    return iterator(it._curpos->next);
}
template <typename T>
inline void list<T>::pop_front()
{
    node* todelete = _head;
    _head = _head->next;
    if (_head == NULL) {
        _tail = NULL;
    }
    _size--;
    delete todelete;
}
template <typename T>
inline void list<T>::clear()
{
    while (begin() != end())
    {
        pop_front();
    }
}
template <typename T>
list<T>& list<T>::operator =(list<T> const& rhs)
{
    clear();

    const_iterator rhs_it = rhs.begin();
    for (rhs_it = rhs.begin(); rhs_it != rhs.end(); ++rhs_it)
    {
        push_back(*rhs_it);
    }

    return *this;
}
template <typename T>
inline size_t list<T>::size() const
{
  return _size;
}

template <typename T>
inline bool list<T>::empty() const
{
  return _size == 0;
}
template <typename T>
inline list<T>::list()
  : _head(NULL), _tail(NULL) @ text

    , _size(0)
{}

template <typename T>
inline list<T>::list(list<T> const& rhs)
  : _head(NULL), _tail(NULL) @ text

    , _size(0)
{
    *this = rhs;
}

template <typename T>
inline list<T>::~list()
{
    clear();
}
